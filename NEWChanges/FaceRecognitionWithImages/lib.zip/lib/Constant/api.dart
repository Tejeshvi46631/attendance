class Constants {
  // static String IP_HEADER =
  //     "http://164.100.112.121/GeoFenceAttendenceMarked/api";
  static String IP_HEADER = "http://164.100.112.121/GeoFenceAttendenceNew/api/";
  //"https://mgov.gov.in/GeoFenceAttendenceSystem/";
  String IP_HEADER1 = "http://164.100.112.121/GeoFenceAttendence/";
  String IP_HEADERIMAGE =
      "http://220.156.188.35/FaceRec/"; //"http://117.239.180.198/BLONet_API_Dev/api/blonet/";

  // live url http://blonetservices.ecinet.in/api/blonet/
}
