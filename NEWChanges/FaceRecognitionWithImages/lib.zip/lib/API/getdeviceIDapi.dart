import 'package:provider/provider.dart';

import '../Constant/api.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../provider/deviceProvider.dart';

class deviceIDcheck {
  Constants constantsInstance = Constants();
// Select Designation API Call
 
}
